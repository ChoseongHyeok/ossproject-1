
#ifndef		__HEADER_H__
#define		__HEADER_H__

#include	<stdio.h>
#include	<unistd.h>
#include	<stdlib.h>
#include	<string.h>
#include	<sys/stat.h>
#include	<sys/types.h>
#include	<dirent.h>
#include	<time.h>
#include	<fnmatch.h>
#include	<pwd.h>
#include	<grp.h>

#endif
